Component({
  properties: {
    type: {
      type: String,
      value: ''
    }
  }
});
