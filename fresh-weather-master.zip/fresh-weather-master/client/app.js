App({
  globalData: {
    nickname: null,
    avatarUrl: null
  }
})
