module.exports = {
  SERVER_URL: 'http://lg-dpu4e0kq-1252758970.file.myqcloud.com',
  STATIC_PATH: '/'
}
